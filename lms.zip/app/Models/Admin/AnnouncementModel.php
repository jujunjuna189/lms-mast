<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class AnnouncementModel extends Model
{
    protected $table = 'announcement';
    protected $guarded = ['id'];
}
