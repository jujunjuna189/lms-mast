<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class MajorModel extends Model
{
    protected $table = 'major';
    protected $guarded = ['id'];
}
