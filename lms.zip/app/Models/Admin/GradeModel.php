<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class GradeModel extends Model
{
    protected $table = 'grade';
    protected $guarded = ['id'];
}
