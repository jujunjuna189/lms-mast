<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class SubjectModel extends Model
{
    protected $table = 'subject';
    protected $guarded = ['id'];
}
