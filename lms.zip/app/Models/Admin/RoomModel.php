<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class RoomModel extends Model
{
    protected $table = 'room';
    protected $guarded = ['id'];
}
