@extends('components/layout/layout-admin-dashboard')
@section('content')
<div class="leading-3">
    <p class="text-xl font-bold">Mata Pelajaran</p>
    <p class="text-sm text-slate-500">Daftar Mata Pelajaran</p>
</div>
<!-- <div class="bg-white p-4 border border-slate-200 rounded-sm">
    <div class="overflow-x-auto bg-white rounded-sm border border-slate-200 ring-1 ring-gray-200 mt-4">
        <table class="min-w-full table-auto text-sm text-left">
            <thead class="bg-slate-200 text-sm sticky top-0 z-10">
                <tr>
                    <th class="px-6 py-3 font-semibold">#</th>
                    <th class="px-6 py-3 font-semibold">Mata Pelajaran</th>
                    <th class="px-6 py-3 font-semibold">Guru Pengampu</th>
                    <th class="px-6 py-3 font-semibold text-center">Materi</th>
                    <th class="px-6 py-3 font-semibold text-center">Tugas</th>
                    <th class="px-6 py-3 font-semibold text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <tr class="hover:bg-gray-100">
                    <td class="px-6 py-1.5">1</td>
                    <td class="px-6 py-1.5 font-medium">Matematika</td>
                    <td class="px-6 py-1.5">Ust. Fadli</td>
                    <td class="px-6 py-1.5 text-center">5</td>
                    <td class="px-6 py-1.5 text-center">2</td>
                    <td class="px-6 py-1.5 text-center">
                        <a href="detail-materi.html" class="inline-block bg-green-700 hover:bg-green-700 text-white px-4 py-1 rounded-sm font-medium text-sm transition">Lihat</a>
                    </td>
                </tr>

                <tr class="bg-gray-100 hover:bg-gray-100">
                    <td class="px-6 py-1.5">2</td>
                    <td class="px-6 py-1.5 font-medium">Fiqih</td>
                    <td class="px-6 py-1.5">Ustadzah Nisa</td>
                    <td class="px-6 py-1.5 text-center">4</td>
                    <td class="px-6 py-1.5 text-center">1</td>
                    <td class="px-6 py-1.5 text-center">
                        <a href="detail-materi.html" class="inline-block bg-green-700 hover:bg-green-700 text-white px-4 py-1 rounded-sm font-medium text-sm transition">Lihat</a>
                    </td>
                </tr>

                <tr class="hover:bg-gray-100">
                    <td class="px-6 py-1.5">3</td>
                    <td class="px-6 py-1.5 font-medium">Bahasa Arab</td>
                    <td class="px-6 py-1.5">Ust. Mahmud</td>
                    <td class="px-6 py-1.5 text-center">6</td>
                    <td class="px-6 py-1.5 text-center">3</td>
                    <td class="px-6 py-1.5 text-center">
                        <a href="detail-materi.html" class="inline-block bg-green-700 hover:bg-green-700 text-white px-4 py-1 rounded-sm font-medium text-sm transition">Lihat</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div> -->
@endsection