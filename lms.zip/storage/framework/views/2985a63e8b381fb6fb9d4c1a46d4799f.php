
<?php $__env->startSection('content'); ?>
<h2 class="text-2xl font-semibold mb-6">Pelajaran yang Telah Diikuti</h2>

<div class="overflow-x-auto bg-white rounded-xl shadow ring-1 ring-gray-200">
    <table class="min-w-full text-sm text-left">
        <thead class="bg-green-700 text-white">
            <tr>
                <th class="px-5 py-3 font-semibold">Tanggal</th>
                <th class="px-5 py-3 font-semibold">Mata Pelajaran</th>
                <th class="px-5 py-3 font-semibold">Guru</th>
                <th class="px-5 py-3 font-semibold text-center">Status</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <tr class="hover:bg-gray-50">
                <td class="px-5 py-4">27 Mei 2025</td>
                <td class="px-5 py-4">Bahasa Arab</td>
                <td class="px-5 py-4">Ustadz Rahman</td>
                <td class="px-5 py-4 text-center">
                    <span class="text-green-700 font-medium bg-green-100 px-3 py-1 rounded-full text-xs">Selesai</span>
                </td>
            </tr>
            <tr class="bg-gray-50 hover:bg-gray-100">
                <td class="px-5 py-4">26 Mei 2025</td>
                <td class="px-5 py-4">Matematika</td>
                <td class="px-5 py-4">Ibu Siti Mulyani</td>
                <td class="px-5 py-4 text-center">
                    <span class="text-green-700 font-medium bg-green-100 px-3 py-1 rounded-full text-xs">Selesai</span>
                </td>
            </tr>
            <tr class="hover:bg-gray-50">
                <td class="px-5 py-4">25 Mei 2025</td>
                <td class="px-5 py-4">Aqidah Akhlak</td>
                <td class="px-5 py-4">Ustadzah Mariam</td>
                <td class="px-5 py-4 text-center">
                    <span class="text-yellow-700 font-medium bg-yellow-100 px-3 py-1 rounded-full text-xs">Belum Tuntas</span>
                </td>
            </tr>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components/layout/layout-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Project-Freelancer\lms\resources\views/history/history.blade.php ENDPATH**/ ?>