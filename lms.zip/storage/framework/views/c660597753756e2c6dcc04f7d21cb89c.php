
<?php $__env->startSection('content'); ?>
<div class="leading-3">
    <p class="text-xl font-bold">Tugas & Ujian</p>
    <p class="text-sm text-slate-500">Daftar Tugas & Ujian</p>
</div>
<div class="bg-white p-4 border border-slate-200 rounded-sm">
    <div class="flex justify-end">
        <button type="button" class="cursor-pointer inline-block bg-green-800 hover:bg-green-700 text-white px-4 py-1 rounded-sm font-medium text-sm transition open-modal" data-id="modalTambahTugas">Tambah</button>
    </div>
    <div class="overflow-x-auto bg-white rounded-sm border border-slate-200 ring-1 ring-gray-200 mt-4">
        <table class="min-w-full table-auto text-sm text-left">
            <thead class="bg-slate-200 text-sm sticky top-0 z-10">
                <tr>
                    <th class="px-6 py-3 font-semibold">#</th>
                    <th class="px-6 py-3 font-semibold">Judul</th>
                    <th class="px-6 py-3 font-semibold">Mata Pelajaran</th>
                    <th class="px-6 py-3 font-semibold text-center">Jenis</th>
                    <th class="px-6 py-3 font-semibold text-center">Deadline</th>
                    <th class="px-6 py-3 font-semibold text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $coursework; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-1.5"><?php echo e($index + 1); ?></td>
                    <td class="px-6 py-1.5 font-medium"><?php echo e($val->title); ?></td>
                    <td class="px-6 py-1.5"><?php echo e($val->subject->title); ?></td>
                    <td class="px-6 py-1.5 text-center"><?php echo e($val->type); ?></td>
                    <td class="px-6 py-1.5 text-center"><?php echo e($val->deadline); ?></td>
                    <td class="px-6 py-1.5 text-center">
                        <button type="button" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-sm font-medium text-sm transition cursor-pointer btn-update" data-class='<?php echo json_encode($val, 15, 512) ?>'>Edit</button>
                        <button type="button" class="inline-block bg-red-600 hover:bg-red-700 text-white px-4 py-1 ml-1 rounded-sm font-medium text-sm transition cursor-pointer btn-delete" data-id='<?php echo e($val->id); ?>'>Hapus</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginal659fba84dde1e096a389b246c5b54638 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal659fba84dde1e096a389b246c5b54638 = $attributes; } ?>
<?php $component = App\View\Components\Modal\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\Modal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'modalTambahTugas','title' => 'Tambah Tugas']); ?>
    <form id="formTambahTugas" action="<?php echo e(route('admin.coursework.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a = $attributes; } ?>
<?php $component = App\View\Components\Field\TextInput::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Field\TextInput::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Judul','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $attributes = $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $component = $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field.select-input','data' => ['name' => 'type','label' => 'Pilih Jenis','options' => [
                'Tugas' => 'Tugas',
                'Ujian' => 'Ujian',
            ],'placeholder' => '-- Pilih Jenis --','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'type','label' => 'Pilih Jenis','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                'Tugas' => 'Tugas',
                'Ujian' => 'Ujian',
            ]),'placeholder' => '-- Pilih Jenis --','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $attributes = $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $component = $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a = $attributes; } ?>
<?php $component = App\View\Components\Field\TextInput::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Field\TextInput::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'deadline','label' => 'Deadline','type' => 'date','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $attributes = $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $component = $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field.select-input','data' => ['name' => 'subject_id','label' => 'Pilih Mata Pelajaran','options' => $subject,'placeholder' => '-- Pilih Mata Pelajaran --','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'subject_id','label' => 'Pilih Mata Pelajaran','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subject),'placeholder' => '-- Pilih Mata Pelajaran --','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $attributes = $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $component = $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field.select-input','data' => ['name' => 'status','label' => 'Pilih Status','options' => [
                'Belum Dikerjakan' => 'Belum Dikerjakan',
                'Selesai' => 'Selesai',
                'Terlambat' => 'Terlambat',
            ],'placeholder' => '-- Pilih Status --','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status','label' => 'Pilih Status','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                'Belum Dikerjakan' => 'Belum Dikerjakan',
                'Selesai' => 'Selesai',
                'Terlambat' => 'Terlambat',
            ]),'placeholder' => '-- Pilih Status --','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $attributes = $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $component = $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>

         <?php $__env->slot('footer', null, []); ?> 
            <button form="formTambahTugas" type="submit" class="bg-green-800 text-white px-4 py-1 rounded hover:bg-green-700 cursor-pointer">Simpan</button>
         <?php $__env->endSlot(); ?>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $attributes = $__attributesOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__attributesOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $component = $__componentOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__componentOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<!-- Edit -->
<?php if (isset($component)) { $__componentOriginal659fba84dde1e096a389b246c5b54638 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal659fba84dde1e096a389b246c5b54638 = $attributes; } ?>
<?php $component = App\View\Components\Modal\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\Modal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'modalEditTugas','title' => 'Edit Tugas']); ?>
    <form id="formEditTugas" action="" method="POST">
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a = $attributes; } ?>
<?php $component = App\View\Components\Field\TextInput::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Field\TextInput::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Judul','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $attributes = $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $component = $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field.select-input','data' => ['name' => 'type','label' => 'Pilih Jenis','options' => [
                'Tugas' => 'Tugas',
                'Ujian' => 'Ujian',
            ],'placeholder' => '-- Pilih Jenis --','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'type','label' => 'Pilih Jenis','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                'Tugas' => 'Tugas',
                'Ujian' => 'Ujian',
            ]),'placeholder' => '-- Pilih Jenis --','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $attributes = $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $component = $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a = $attributes; } ?>
<?php $component = App\View\Components\Field\TextInput::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Field\TextInput::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'deadline','label' => 'Deadline','type' => 'date','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $attributes = $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $component = $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field.select-input','data' => ['name' => 'subject_id','label' => 'Pilih Mata Pelajaran','options' => $subject,'placeholder' => '-- Pilih Mata Pelajaran --','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'subject_id','label' => 'Pilih Mata Pelajaran','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subject),'placeholder' => '-- Pilih Mata Pelajaran --','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $attributes = $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $component = $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field.select-input','data' => ['name' => 'status','label' => 'Pilih Status','options' => [
                'Belum Dikerjakan' => 'Belum Dikerjakan',
                'Selesai' => 'Selesai',
                'Terlambat' => 'Terlambat',
            ],'placeholder' => '-- Pilih Status --','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status','label' => 'Pilih Status','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                'Belum Dikerjakan' => 'Belum Dikerjakan',
                'Selesai' => 'Selesai',
                'Terlambat' => 'Terlambat',
            ]),'placeholder' => '-- Pilih Status --','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $attributes = $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $component = $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>

         <?php $__env->slot('footer', null, []); ?> 
            <button form="formEditTugas" type="submit" class="bg-green-800 text-white px-4 py-1 rounded hover:bg-green-700 cursor-pointer">Simpan</button>
         <?php $__env->endSlot(); ?>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $attributes = $__attributesOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__attributesOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $component = $__componentOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__componentOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<!-- delete confirm -->
<?php if (isset($component)) { $__componentOriginal659fba84dde1e096a389b246c5b54638 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal659fba84dde1e096a389b246c5b54638 = $attributes; } ?>
<?php $component = App\View\Components\Modal\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\Modal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'modalHapusTugas','title' => 'Konfirmasi Hapus']); ?>
    <form id="formHapusTugas" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <p class="text-sm text-gray-700 mb-4">
            Apakah Anda yakin ingin menghapus <strong>tugas <span id="tugas"></span></strong>? Tindakan ini tidak dapat dibatalkan.
        </p>

         <?php $__env->slot('footer', null, []); ?> 
            <button form="formHapusTugas" type="submit" class="bg-red-700 text-white px-4 py-1 rounded hover:bg-red-600">Hapus</button>
         <?php $__env->endSlot(); ?>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $attributes = $__attributesOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__attributesOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $component = $__componentOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__componentOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).on('click', '.btn-update', function() {
        const data = $(this).data('class');

        $('#formEditTugas').attr('action', `/admin/coursework/${data.id}`);
        $('#formEditTugas input[name="title"]').val(data.title);
        $('#formEditTugas select[name="type"]').val(data.type);
        $('#formEditTugas input[name="deadline"]').val(data.deadline);
        $('#formEditTugas select[name="subject_id"]').val(data.subject_id);
        $('#formEditTugas select[name="status"]').val(data.status);

        $('#modalEditTugas').removeClass('hidden').addClass('flex');
    });

    $(document).on('click', '.btn-delete', function() {
        const id = $(this).data('id');

        $('#formHapusTugas').attr('action', `/admin/coursework/${id}`);
        $('#modalHapusTugas').removeClass('hidden').addClass('flex');;
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components/layout/layout-admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Project-Freelancer\lms\resources\views/admin/coursework/coursework.blade.php ENDPATH**/ ?>