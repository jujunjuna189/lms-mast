
<?php $__env->startSection('content'); ?>
<div class="leading-3">
    <p class="text-xl font-bold">Kelas</p>
    <p class="text-sm text-slate-500">Daftar Kelas</p>
</div>
<div class="bg-white p-4 border border-slate-200 rounded-sm">
    <div class="flex justify-end">
        <button type="button" class="cursor-pointer inline-block bg-green-800 hover:bg-green-700 text-white px-4 py-1 rounded-sm font-medium text-sm transition open-modal" data-id="modalTambahKelas">Tambah</button>
    </div>
    <div class="overflow-x-auto bg-white rounded-sm border border-slate-200 ring-1 ring-gray-200 mt-4">
        <table class="min-w-full table-auto text-sm text-left">
            <thead class="bg-slate-200 text-sm sticky top-0 z-10">
                <tr>
                    <th class="px-6 py-3 font-semibold">#</th>
                    <th class="px-6 py-3 font-semibold">Tingkat</th>
                    <th class="px-6 py-3 font-semibold">Jurusan</th>
                    <th class="px-6 py-3 font-semibold">Nama Kelas</th>
                    <th class="px-6 py-3 font-semibold">Wali Kelas</th>
                    <th class="px-6 py-3 font-semibold text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-100">
                    <td class="px-6 py-1.5"><?php echo e($index + 1); ?></td>
                    <td class="px-6 py-1.5"><?php echo e($val->grade->title); ?></td>
                    <td class="px-6 py-1.5"><?php echo e($val->major->title); ?></td>
                    <td class="px-6 py-1.5"><?php echo e($val->name); ?></td>
                    <td class="px-6 py-1.5"><?php echo e($val->class_teacher); ?></td>
                    <td class="px-6 py-1.5 text-center">
                        <button type="button" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-sm font-medium text-sm transition cursor-pointer btn-update" data-class='<?php echo json_encode($val, 15, 512) ?>'>Edit</button>
                        <button type="button" class="inline-block bg-red-600 hover:bg-red-700 text-white px-4 py-1 ml-1 rounded-sm font-medium text-sm transition cursor-pointer btn-delete" data-id='<?php echo e($val->id); ?>'>Hapus</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginal659fba84dde1e096a389b246c5b54638 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal659fba84dde1e096a389b246c5b54638 = $attributes; } ?>
<?php $component = App\View\Components\Modal\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\Modal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'modalTambahKelas','title' => 'Tambah Kelas']); ?>
    <form id="formTambahKelas" action="<?php echo e(route('admin.class.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field.select-input','data' => ['name' => 'grade_id','label' => 'Pilih Tingkat','options' => $grade,'placeholder' => '-- Pilih Tingkat --','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'grade_id','label' => 'Pilih Tingkat','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($grade),'placeholder' => '-- Pilih Tingkat --','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $attributes = $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $component = $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field.select-input','data' => ['name' => 'major_id','label' => 'Pilih Jurusan','options' => $major,'placeholder' => '-- Pilih Jurusan --','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'major_id','label' => 'Pilih Jurusan','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($major),'placeholder' => '-- Pilih Jurusan --','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $attributes = $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $component = $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a = $attributes; } ?>
<?php $component = App\View\Components\Field\TextInput::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Field\TextInput::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Nama Kelas','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $attributes = $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $component = $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a = $attributes; } ?>
<?php $component = App\View\Components\Field\TextInput::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Field\TextInput::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'class_teacher','label' => 'Wali Kelas','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $attributes = $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $component = $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
         <?php $__env->slot('footer', null, []); ?> 
            <button form="formTambahKelas" type="submit" class="bg-green-800 text-white px-4 py-1 rounded hover:bg-green-700 cursor-pointer">Simpan</button>
         <?php $__env->endSlot(); ?>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $attributes = $__attributesOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__attributesOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $component = $__componentOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__componentOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<!-- Update -->
<?php if (isset($component)) { $__componentOriginal659fba84dde1e096a389b246c5b54638 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal659fba84dde1e096a389b246c5b54638 = $attributes; } ?>
<?php $component = App\View\Components\Modal\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\Modal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'modalEditKelas','title' => 'Edit Kelas']); ?>
    <form id="formEditKelas" method="POST">
        <?php echo csrf_field(); ?>

        <?php if (isset($component)) { $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field.select-input','data' => ['name' => 'grade_id','label' => 'Pilih Tingkat','options' => $grade,'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'grade_id','label' => 'Pilih Tingkat','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($grade),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $attributes = $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $component = $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field.select-input','data' => ['name' => 'major_id','label' => 'Pilih Jurusan','options' => $major,'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'major_id','label' => 'Pilih Jurusan','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($major),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $attributes = $__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__attributesOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0)): ?>
<?php $component = $__componentOriginal8104024dc2bfa4fc467c219472c6f0a0; ?>
<?php unset($__componentOriginal8104024dc2bfa4fc467c219472c6f0a0); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a = $attributes; } ?>
<?php $component = App\View\Components\Field\TextInput::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Field\TextInput::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Nama Kelas','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $attributes = $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $component = $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a = $attributes; } ?>
<?php $component = App\View\Components\Field\TextInput::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field.text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Field\TextInput::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'class_teacher','label' => 'Wali Kelas','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $attributes = $__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__attributesOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a)): ?>
<?php $component = $__componentOriginalf65f53d2fe50a974631df8bf8873fe0a; ?>
<?php unset($__componentOriginalf65f53d2fe50a974631df8bf8873fe0a); ?>
<?php endif; ?>

         <?php $__env->slot('footer', null, []); ?> 
            <button form="formEditKelas" type="submit" class="bg-blue-800 text-white px-4 py-1 rounded hover:bg-blue-700 cursor-pointer">Update</button>
         <?php $__env->endSlot(); ?>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $attributes = $__attributesOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__attributesOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $component = $__componentOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__componentOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<!-- delete confirm -->
<?php if (isset($component)) { $__componentOriginal659fba84dde1e096a389b246c5b54638 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal659fba84dde1e096a389b246c5b54638 = $attributes; } ?>
<?php $component = App\View\Components\Modal\Modal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\Modal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'modalHapusKelas','title' => 'Konfirmasi Hapus']); ?>
    <form id="formHapusKelas" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <p class="text-sm text-gray-700 mb-4">
            Apakah Anda yakin ingin menghapus <strong>kelas <span id="kelasNama"></span></strong>? Tindakan ini tidak dapat dibatalkan.
        </p>

         <?php $__env->slot('footer', null, []); ?> 
            <button form="formHapusKelas" type="submit" class="bg-red-700 text-white px-4 py-1 rounded hover:bg-red-600">Hapus</button>
         <?php $__env->endSlot(); ?>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $attributes = $__attributesOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__attributesOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal659fba84dde1e096a389b246c5b54638)): ?>
<?php $component = $__componentOriginal659fba84dde1e096a389b246c5b54638; ?>
<?php unset($__componentOriginal659fba84dde1e096a389b246c5b54638); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).on('click', '.btn-update', function() {
        const data = $(this).data('class');

        $('#formEditKelas').attr('action', `/admin/class/${data.id}`);
        $('#formEditKelas input[name="name"]').val(data.name);
        $('#formEditKelas input[name="class_teacher"]').val(data.class_teacher);
        $('#formEditKelas select[name="grade_id"]').val(data.grade_id);
        $('#formEditKelas select[name="major_id"]').val(data.major_id);

        $('#modalEditKelas').removeClass('hidden').addClass('flex');
    });

    $(document).on('click', '.btn-delete', function() {
        const id = $(this).data('id');

        $('#formHapusKelas').attr('action', `/admin/class/${id}`);
        $('#modalHapusKelas').removeClass('hidden').addClass('flex');;
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components/layout/layout-admin-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Project-Freelancer\lms\resources\views/admin/class/class.blade.php ENDPATH**/ ?>