<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'id' => 'modal-id',
'title' => 'Modal Title',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'id' => 'modal-id',
'title' => 'Modal Title',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div id="<?php echo e($id); ?>" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/50">
    <div class="bg-white rounded-lg shadow-lg w-full max-w-lg mx-4 relative">
        <!-- Header -->
        <div class="flex justify-between items-center px-4 py-3 border-b border-slate-200">
            <h3 class="text-lg font-semibold text-gray-800"><?php echo e($title); ?></h3>
            <button class="text-gray-500 hover:text-gray-700 text-xl close-modal cursor-pointer" data-id="<?php echo e($id); ?>">&times;</button>
        </div>

        <!-- Body -->
        <div class="p-4">
            <?php echo e($slot); ?>

        </div>

        <!-- Footer -->
        <div class="flex justify-end items-center px-4 py-2 border-t border-slate-200 gap-2">
            <button class="bg-gray-200 text-gray-700 px-4 py-1 rounded hover:bg-gray-300 close-modal cursor-pointer" data-id="<?php echo e($id); ?>">Tutup</button>
            <?php echo e($footer ?? ''); ?>

        </div>
    </div>
</div><?php /**PATH D:\Project-Koding\Laravel\Project-Freelancer\lms\resources\views/components/modal/modal.blade.php ENDPATH**/ ?>